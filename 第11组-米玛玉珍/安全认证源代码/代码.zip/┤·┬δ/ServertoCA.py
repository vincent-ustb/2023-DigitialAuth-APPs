import base64
import mysql.connector
import pymysql
import createserverkey
import hashlib
import CA
import requests
# 连接到MySQL据库
config={'host':'127.0.0.1', 'user':'root', 'password':'root', 'database':'chatroom'}
connection = mysql.connector.connect(**config)
cursor = connection.cursor()
def validate_website(website):
    try:
        response = requests.head(website)
        if response.status_code == 200:
            return True
        else:
            return False
    except requests.exceptions.RequestException:
        return False
def Concatenate_and_Encode(strings):
    # 使用"&"拼接多个字符串
    concatenated_string = "&".join(strings)
    # 将拼接后的字符串转换为字节数组
    bytes_str = concatenated_string.encode('utf-8')
    # 对字节数组进行base64编码
    encoded_str = base64.b64encode(bytes_str)
    # 将字节数组转换为字符串
    encoded_str = encoded_str.encode('utf-8')
    return encoded_str

# 要求用户输入网站信息
domain = input("请输入网站信息：")
if validate_website(domain):
    server_publickey,server_privatekey=createserverkey.returnkey()
    strings = domain+"&"+server_publickey
    print("网站信息+公钥："+str(strings))
    message=CA.newcrt(strings)
    print("CA证书摘要："+str(message))
    query = f"insert into certificates(name,public_key,message)values('{domain}','{strings}','{message}')"
    cursor.execute(query)
else:
    print(f"网站{domain}不存在")

