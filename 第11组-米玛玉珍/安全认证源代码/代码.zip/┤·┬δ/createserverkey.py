import random
import base64

def generate_key():
    key1 = random.randint(10000000000, 99999999999)
    key2 = random.randint(10000000000, 99999999999)
    
    # 确保密钥的首位和末位不为0
    key1 = int(str(key1)[1:-1])
    key2 = int(str(key2)[1:-1])
    publickey = str(base64.b64encode(str(key1).encode('utf-8')), 'utf-8')
    privatekey = str(base64.b64encode(str(key2).encode('utf-8')), 'utf-8')
    return publickey, privatekey
def returnkey():
    # 生成密钥
    publickey = ""
    privatekey = ""
    while publickey == privatekey:
        publickey, privatekey = generate_key()
    # 将密钥打印出来
    print("服务器公钥："+publickey)
    print("服务器私钥："+privatekey)
    return publickey,privatekey
