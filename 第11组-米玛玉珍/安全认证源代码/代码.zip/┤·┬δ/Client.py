import socket
import pickle
import CA
import base64
import hashlib
import webbrowser
import time
import requests
import createclientkey
print("111")
def validate_website(website):
    try:
        response = requests.head(website)
        if response.status_code == 200:
            return True
        else:
            return False
    except requests.exceptions.RequestException:
        return False
def base64_decode(encoded_string):
    # 将 base64 编码的字符串解码为二进制数据
    decoded_bytes = base64.b64decode(encoded_string)
    
    # 将二进制数据转换为字符串
    decoded_string = decoded_bytes.decode('latin-1')
    
    return decoded_string
# 创建一个socket对象
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 服务器的IP和端口
host = '127.0.0.1'
port = 12345

# 连接服务器
client_socket.connect((host, port))

# 发送请求给服务器
request = input("请输入要访问的网站：")
if validate_website(request):
    client_socket.send(request.encode())

    # 接收服务器返回的数据
    result = client_socket.recv(1024)
    data = pickle.loads(result)
    print("连接服务器····")
    if(data[0]!=0 and data[1]!=0):
        print("该网站服务器信息："+data[0])
        print("该网站证书签名："+data[1])
        print("验证中····")
        ca_publickey=CA.getCApublickey()
        key = int(ca_publickey[-5])
        strings=data[1]
        for i in range(key):
            strings=base64_decode(strings)
        # 将服务器信息hash加密
        # 1创建SHA256对象
        sha256_hash = hashlib.sha256()
        cleardata0=str(data[0]).rstrip('\n')
        # 2更新哈希对象的内容为要加密的字符串
        sha256_hash.update(cleardata0.encode('utf-8'))
        # 3获取加密后的十六进制字符串
        hashed_strings = sha256_hash.hexdigest()
        print(strings)
        print(hashed_strings)
        if(strings==hashed_strings):
            print("证书验证通过，网站安全")
            time.sleep(3)
            url = '10.39.124.186/chatroom/login.html'  # 替换为你要打开的网页的 URL
            webbrowser.open(url)
            key=createclientkey.returnkey()
            client_socket.send(key.encode())
        else:
            print("证书验证失败，无法判断该网站是否安全")
        # 关闭客户端连接
        client_socket.close()
    else:
        print(request+"该网站服务未在CA机构认证")
    # 关闭客户端连接
    client_socket.close()
else:
    print(f"网站{request}不存在")
