import random
import base64

def generate_key():
    key = random.randint(10000000000, 99999999999)
    # 确保密钥的首位和末位不为0
    key = int(str(key)[1:-1])
    key = str(base64.b64encode(str(key).encode('utf-8')), 'utf-8')
    return key
def returnkey():
    # 生成密钥
    key = generate_key()
    # 将密钥打印出来
    print("客户端密钥："+key)
    return key
