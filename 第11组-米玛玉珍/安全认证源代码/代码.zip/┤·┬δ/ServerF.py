import socket
import base64
import mysql.connector
import pymysql
import createserverkey
import hashlib
import CA
import pickle
config={'host':'127.0.0.1', 'user':'root', 'password':'root', 'database':'chatroom'}
connection = mysql.connector.connect(**config)
cursor = connection.cursor()
# 创建一个socket对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 监听的IP和端口
host = '127.0.0.1'
port = 12345
# 绑定IP和端口
server_socket.bind((host, port))
# 监听最多1个客户端连接
server_socket.listen(1)
while True:
    # 接受客户端连接
    client_socket, addr = server_socket.accept()
    print('Connected by', addr)
    # 接收客户端发来的数据
    request = client_socket.recv(1024).decode()
    query = f"select public_key,message from certificates where name='{request}';"
    cursor.execute(query)
    results = cursor.fetchall()
    if len(results) == 0:
        result=[0,0]
    else:
        result_str1=""
        result_str2=""
        for row in results:
        # 使用索引或字段名称来访问所需的列
            result_str1 += str(row[0]) + "\n"
            result_str2 += str(row[1]) + "\n"
        print("发送服务端信息和证书签名："+result_str1,result_str2)
        result=[]
        result.append(result_str1)
        result.append(result_str2)
    # 将列表对象转换为字符串
    data_str = pickle.dumps(result)
    # 向客户端发送数据
    client_socket.send(data_str)
    key = client_socket.recv(1024).decode()
    print("已接受用户端传输密钥："+key)
    query1 = f"insert into client_key (`key`) values ('{key}')"
    cursor.execute(query1)
    # 关闭客户端连接
    client_socket.close()
