<?php
session_start();
header('content-type:text/html;charset=utf-8');

if (!isset($_SESSION['info']['Id'])) {
    // 处理不存在的情况
    var_dump($_SESSION);
    exit("Session data not set");
}
//引入工具
include_once "./Tools/phpTools.php";
$userId = $_SESSION['info']['Id'];
$sql1 = "SELECT `key` FROM client_key LIMIT 1";
$key = mysqli_excute_select($sql1);
$key = $key[0]["key"];
// 1.接受用户通过 POST 方式传递的聊天内容
if (isset($_POST['messageContent'])) {
    $messageContent = $_POST['messageContent'];
} else {
    // 处理不存在的情况
    exit("Message content not set");
}
function generateRandomBytes($size) {
    $bytes = '';
    for ($i = 0; $i < $size; $i++) {
        $bytes .= chr(mt_rand(0, 255));
    }
    return $bytes;
}
function encrypt($string, $key) {
    $key = (string) $key;
    $iv = generateRandomBytes(openssl_cipher_iv_length('AES-256-CBC'));
    $encryptedString = openssl_encrypt($string, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($encryptedString . '::' . $iv);
}

$encryptedString = encrypt($messageContent, $key);
$_SESSION['keymessage'] = $encryptedString;
header("location: ./server.php");
?>