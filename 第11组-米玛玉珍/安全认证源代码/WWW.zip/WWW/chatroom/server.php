<?php
    header('content-type:text/html;charset=utf-8');
    session_start();
    $userId = $_SESSION['info']['Id'];
    $encryptedString = $_SESSION['keymessage'];
    include_once "./Tools/phpTools.php";
    $userId = $_SESSION['info']['Id'];
    $sql1 = "SELECT `key` FROM client_key LIMIT 1";
    $key = mysqli_excute_select($sql1);
    $key = $key[0]["key"];
    echo($encryptedString);
    function decrypt($encryptedString, $key) {
    	$data = base64_decode($encryptedString);
    	list($encryptedString, $iv) = explode('::', $data, 2);
    	return openssl_decrypt($encryptedString, 'AES-256-CBC', $key, 0, $iv);
	}
    $messageContent = decrypt($encryptedString, $key);
    echo($messageContent);
    // 2.引入工具
    include_once "./Tools/phpTools.php";
    // 3.把这个聊天内容插入到chat_message数据表中
    $sql = "insert into chat_message(user_id,content) values('$userId','$messageContent')";
    // 4.执行sql语句
    $arr = mysqli_excute_zsg($sql);
    if($arr > 0){
        header("location:./chat.php");
    }else{
        echo "发送失败";
    }
?>