<?php
session_start();
$a = $_POST['key'];
echo "__________________";
echo $a;
$_SESSION['key'] = $a;
?>